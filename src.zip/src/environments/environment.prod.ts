export const environment = {
  production: true,

  api: 'https://skerlingo.com/api',
  apiVersion: '/v1/',
  appKey: 'fdfha8OWVugDS7FbHYPLNFfc4dL4ngl1fpHFNCX6anAM1gxMQErhdxwaJWdpwyTM',

  requestEncryption: 'none',
  useStaticApiKey: false,
  storagePassword: 'ShouldBeGenerated',
};
