export const isMobile = () => {
	return window.parent.innerWidth <= 640;
};