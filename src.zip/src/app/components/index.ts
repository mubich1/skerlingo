/**
 * contains all components
 * include and index.php in the components folder
 * and export the folder
 */

// export * from './component';
