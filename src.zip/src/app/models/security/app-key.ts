export interface AppKey {
  publicKey: string;
  privateKey: string;
}
