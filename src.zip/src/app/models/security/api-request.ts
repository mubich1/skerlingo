export class APIRequest {
  data: any;
  dataSize: number;
  key: string;
}
