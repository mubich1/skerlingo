export class ApiCredentials {
  uniqueId?: any;
  email: string;
  password: string;
}
