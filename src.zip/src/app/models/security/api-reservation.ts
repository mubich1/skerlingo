export class ApiReservation {
  id: number;
  prestations: any;
  produits: any;
  date: string;
  duree: string;
  prix: number;
  total: number;
  heure: string;
  membre: string;
  
  service_id: Number;
  reponses: any;
  type: string;
  message: string;
  services_optionnel: any;
}
