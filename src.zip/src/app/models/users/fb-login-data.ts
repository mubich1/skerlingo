export class FbLoginData {
  accessToken: string;
  expiresIn: number;
  sig: string;
  session_key: boolean;
  userID: string;
}
