export class CheckProviderData {
  provider: string;
  email: string;
  lastName: string;
  firstName: string;
}