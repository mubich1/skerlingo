export class Profile {
  id?: number;
  nomComplet?: string;
  nom: string;
  prenom: string;
  email: string;
  tel: string;
  image_url?: string;
  photo: string;
  logo?:string;
  success?: boolean;
}
