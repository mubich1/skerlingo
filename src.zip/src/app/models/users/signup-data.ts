export class SignupData {
  provider: string;
  email: string;
  lastName: string;
  firstName: string;
  password: string;
  passwordC: string;
}