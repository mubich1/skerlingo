export class GpLoginData {
  accessToken: string;
  displayName: string;
  email: string;
  expires: number;
  expires_in: number;
  familyName: string;
  givenName: string;
  imageUrl: string;
  userId: string;
  
}
