export class ProduitData {
  label: string;
  prix: string;
  categorie_label: string;
  image_url: string;
  description: string;
}
