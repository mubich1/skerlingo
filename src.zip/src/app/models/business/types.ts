export type HomeType = 'list' | 'slider';
