export class CategorieData {
  title: string;
  description: string;
  image_url: string;
  lecons: any;
}
