export class PanierData {
  prestations: [];
  produits: [];
  prix: any;
  duree: any;
  total: any;
}
