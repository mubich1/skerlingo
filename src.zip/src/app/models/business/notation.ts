export class NotationData {
  label: string;
  description: string;
  statut: any;
  image_url: string;
  counter: any;
  participate: boolean;
  participate_msg: string;
  participate_icon: string;
}
