//import { Prestation } from './prestations';

export class SearchData {
  title: string;
  description: string;
  date: Date;
  banner: string;

  salons: [];
}
