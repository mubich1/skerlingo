export class BoutiqueData {
  categories: any;
  populaires: any;
  produits: any;
}
