export class CreneauxData {
  calendar: any;
}
