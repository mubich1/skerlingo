export class EtapesData {
  etapes: any;
  reponses: any;
  services_optionnel: any;
}
