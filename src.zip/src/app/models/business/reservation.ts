export class ReservationData {
  membres: [];
  prestations: [];
  duree: any;
  prix: any;
}
