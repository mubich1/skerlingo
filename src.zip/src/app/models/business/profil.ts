export class ProfilData {
  next_reservation: any;
  reservations: [];
  evaluations: [];
  commandes: [];
  client: any;
}
