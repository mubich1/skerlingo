export class Prestation {
  id: number;
  name: string;
}
