export class PrestationCateg {
  id: number;
  name: string;
}
