export class EtapeData {
  etape: any;
  messages: any;
  reponses: any;
  services_optionnel: any;
}
