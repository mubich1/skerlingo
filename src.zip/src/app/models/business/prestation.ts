export class PrestationData {
  id: Number;
  categorie_label: string;
  label: string;
  image_url: string;
  description: string;
  time_to_deliver: number;
  montant: string;
  questions: any;
  services_optionnel: any;
  services: any;
}
