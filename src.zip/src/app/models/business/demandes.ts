export class DemandesData {
  demandes_service: any;
  demandes_specific: any;
}
